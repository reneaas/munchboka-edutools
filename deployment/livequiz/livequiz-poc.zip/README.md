# Livequiz proof of concept

A teacher-controlled classroom quiz at `https://jeopardy.munchboka.no/livequiz/`.
Uses PHP 8.4 and the **existing Jeopardy MySQL database**. No second database,
WebSocket subscription, Node server or build step is required on the host.
No deployment has been performed by creating these files.

## Included

- Jeopardy's existing Osloskolen sign-in and accounts. Sign in on the existing
  homepage, then return to `/livequiz/?teacher=1`. Students join without accounts.
- Quiz library, creation, editing, explicit online saves and revision conflict
  checks. One to fifty questions, two to six choices, 5–600 second answer windows.
- One correct choice, multiple correct choices (exact set), or typed accepted
  answers (case/whitespace normalization; no algebraic equivalence or tolerance).
- Text, safe LaTeX via existing local KaTeX assets, literal code blocks, uploaded
  images via existing private Jeopardy media storage, and click-to-load YouTube
  embeds. Code is displayed, not executed. YouTube is an external service; school
  network and video permissions determine actual playback. Projector/player video
  playback is independent, not synchronized. The timer continues during videos.
- Separate six-digit PIN for each session, locally generated QR code, lobby,
  teacher-controlled questions, deadline, reveal, final scoreboard and recovery
  after refreshing the same student tab. Student tokens stay in sessionStorage;
  opening a different tab/device does not recover that player automatically.
- 1000 points for a correct answer, zero otherwise; no speed bonus or partial credit.
- Snapshot isolation: editing a quiz does not change already-created sessions.
- One poll per second per device, non-overlapping requests, retry backoff and
  visible connection status. Server deadlines and first-answer-wins semantics.
- Maximum 60 participants per room and six-hour room access. These are application
  limits, **not a measured hosting capacity guarantee**. New players join only in
  the lobby; existing players may reconnect after the game starts.

## cPanel installation (additive)

This is an add-on to the existing Jeopardy deployment, on the **same hostname**.
Its host-only login cookie is shared intentionally. A different subdomain would
need an authentication integration change.

1. Take a database backup through cPanel before importing new tables.
2. In phpMyAdmin select the **existing Jeopardy database** and import
   `private/livequiz/schema.sql`. It creates only `lq_quizzes`, `lq_rooms`,
   `lq_players`, and `lq_answers` using `CREATE TABLE IF NOT EXISTS`.
   It does not create a database, alter/drop `jp_*` tables or touch saved games.
3. Upload `private/livequiz/` as
   `/home/zebfxvix/jeopardy-private/livequiz/`.
4. Upload `public/livequiz/`, including `.htaccess` and `vendor/`, as
   `/home/zebfxvix/public_html/jeopardy/livequiz/`.
5. Leave existing `jeopardy-private/database.php`, `app.php`, and `schema.sql`
   intact. The new private app loads the existing `app.php` and calls `jp_db()`;
   the **same credentials and database** are reused. Existing accounts and image
   quota/storage are reused too. Never upload private files into the public root.
6. The public entry point expects
   `/home/zebfxvix/jeopardy-private/livequiz/app.php`. If your hosting account path
   differs, update that path in `public/livequiz/index.php` before uploading.
7. Sign in at the existing Jeopardy homepage. Open `/livequiz/?teacher=1`, create
   a short quiz, save and start it. Join using an anonymous/private browser on a
   second device. Test every answer type, math, an image and your chosen video.
8. Test a small class before expanding. Inspect hosting CPU/entry-process limits
   and response times. Concurrent room transitions and submissions use InnoDB
   row locks and must be checked on the real MySQL host.

The generated ZIP contains `public/livequiz/` and `private/livequiz/` plus this
README. **Do not extract the whole archive into public_html**. Upload/extract in
an account-private staging folder, then move its two livequiz directories to the
respective destinations above. No credentials or test login are included.

Rollback: remove the two newly uploaded `livequiz/` directories. The original
Jeopardy files are unchanged. New tables can remain until you decide what to
retain; this proof of concept provides no destructive rollback script.

## Data, access and limits

Owner checks and CSRF protect teacher actions. Student tokens are 256-bit random
secrets; the database stores only their SHA-256 hashes. A room PIN permits joining,
not hosting or fetching the answer key. Only the current question is exposed;
answers/grades are withheld until the teacher reveals or finishes the game.
Room-scoped image access checks the current question and original ownership.
Answers and room transitions share a room row lock. Duplicate answer retries
acknowledge the first answer without changing its score. Timer expiry closes
submissions server-side; the teacher explicitly reveals the answer.

The current auth system treats every verified Osloskolen account alike, so both
teachers and students with those accounts can author/host. There is no staff-role
directory. Participants see nicknames and scores at reveal/end. Encourage aliases.

This is a classroom proof of concept, not a production-scale launch. Join attempts
are throttled per PHP session (two seconds), not globally or per IP; hostile clients
can evade this. There is no moderation, player removal, result export, session
resume across devices, deletion UI, automatic cleanup, or offline draft recovery.
Expiry blocks access but **does not delete** quizzes, participants, answers or
images. Removed images remain under Jeopardy's existing retention behavior and
50 MiB account quota. Agree retention/deletion and privacy arrangements before
wider use. Quizzes retain only their latest saved version; running rooms retain
snapshots. No new email integration or student email collection is introduced.

## Verification (2026-10-22)

- 50 backend checks passed under PHP 8.4 with an isolated SQLite database.
- Separate teacher and mobile student browser contexts passed quiz creation,
  image upload/display, math rendering, code display, PIN/QR generation, all
  three answer types, refresh recovery, answer reveal and the 3000-point final
  score. Missing CSRF and unauthenticated teacher mutations were rejected.
- Desktop lobby and mobile question screenshots were visually inspected.
- JavaScript/Python syntax checks passed. PHP source syntax checks passed.
- No live hosting files, credentials or databases were modified. MySQL
  concurrency, real-school network behavior, QR scanning on a physical phone,
  real YouTube playback and classroom load remain deployment checks.

## Tests and local fixture

`php tests/core.php` runs backend integration checks against SQLite, removing
MySQL's `FOR UPDATE` clause in a test-only PDO subclass. It covers validation,
ownership, revisions, snapshots, hidden answers/scores, participant credentials,
join/answer retries, deadlines, full-game scoring and media scoping. It does not
prove MySQL locking under concurrent load.

For an isolated browser fixture (requires PHP 8.4 with PDO SQLite, Fileinfo and
image metadata support, Python 3, Node and Playwright):

```sh
python3 tests/prepare-local.py /private/tmp/livequiz-browser
php /private/tmp/livequiz-browser/setup.php
LIVEQUIZ_LOCAL=1 LIVEQUIZ_PRIVATE=/private/tmp/livequiz-browser/private/livequiz/app.php php -S 127.0.0.1:8765 -t /private/tmp/livequiz-browser/public
```

In another terminal run `node tests/browser.cjs` with Playwright resolvable, or set
`PLAYWRIGHT_MODULE` to its installed module path. `CHROMIUM_PATH` optionally selects
an existing browser executable. The fixture uses an isolated database and a
**test-only login page**. Never upload the fixture or tests to hosting.

The browser test creates a quiz, uploads an image, checks math/code display,
generates PIN/QR, joins through a separate mobile-sized browser context, answers,
refreshes, reveals and verifies the final score. YouTube embedding is checked
with a locally intercepted frame; it does not verify external video playback.

## Third-party assets

`public/livequiz/vendor/qrcode.js`: qrcode-generator 1.4.4 by Kazuhiko Arase,
MIT license bundled in `vendor/LICENSE`, obtained from the version-pinned npm
package via jsDelivr. Upstream: https://github.com/kazuhikoarase/qrcode-generator.
No external QR service receives the join URL. KaTeX and math rendering are loaded
from the existing Jeopardy site's local files; they are not duplicated in this ZIP.
