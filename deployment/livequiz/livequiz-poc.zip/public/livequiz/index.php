<?php
declare(strict_types=1);
ini_set('display_errors', '0');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY');
header('X-Robots-Tag: noindex, nofollow');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; frame-src https://www.youtube-nocookie.com; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
$local = PHP_SAPI === 'cli-server' && getenv('LIVEQUIZ_LOCAL') === '1';
if (!$local && ($_SERVER['HTTPS'] ?? '') !== 'on') { header('Location: https://jeopardy.munchboka.no/livequiz/', true, 302); exit; }
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_name($local ? 'livequiz-local' : '__Host-jeopardy');
session_set_cookie_params(['lifetime'=>0, 'path'=>'/', 'secure'=>!$local, 'httponly'=>true, 'samesite'=>'Lax']);
session_start();
if (isset($_SESSION['uid']) && time() - ($_SESSION['authenticated_at'] ?? 0) > 28800) { $_SESSION = []; session_regenerate_id(true); }
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
$uid = (int)($_SESSION['uid'] ?? 0); $csrf = $_SESSION['csrf'];
function lq_response(array $data, int $status = 200): never {
    http_response_code($status); header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_THROW_ON_ERROR); exit;
}
$action = $_GET['api'] ?? null;
if ($action !== null) {
    try {
        if (!is_string($action)) throw new DomainException('Ugyldig forespørsel.');
        $post = $_SERVER['REQUEST_METHOD'] === 'POST';
        $mutations = ['save','create','join','control','answer','upload'];
        if (in_array($action, $mutations, true) !== $post) throw new DomainException('Ugyldig metode.');
        if ($post && !hash_equals($csrf, $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) lq_response(['error'=>'Siden er utløpt. Åpne en ny fane og logg inn igjen. Behold denne fanen med arbeidet ditt.'], 403);
        if ($action === 'join') {
            if (time() < ($_SESSION['lq_join_after'] ?? 0)) lq_response(['error'=>'Vent to sekunder og prøv igjen.'], 429);
            $_SESSION['lq_join_after'] = time() + 2;
        }
        // Release PHP's session lock before polling queries, uploads or room locks.
        session_write_close();
        if ($action === 'bootstrap') lq_response(['uid'=>$uid, 'csrf'=>$csrf]);
        $teacherActions = ['library','quiz','save','create','control','upload'];
        if (in_array($action, $teacherActions, true) && !$uid) lq_response(['error'=>'Logg inn via Jeopardy i en ny fane først.'], 401);
        require getenv('LIVEQUIZ_PRIVATE') ?: '/home/zebfxvix/jeopardy-private/livequiz/app.php';
        $db = jp_db();
        $input = [];
        if ($post && $action !== 'upload') {
            $raw = file_get_contents('php://input', false, null, 0, 1100001);
            if (strlen($raw) > 1100000) throw new DomainException('Forespørselen er for stor.');
            $input = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
            if (!is_array($input)) throw new DomainException('Ugyldig forespørsel.');
        }
        $token = $_SERVER['HTTP_X_PLAYER_TOKEN'] ?? '';
        if (strlen($token) > 64) throw new DomainException('Ugyldig deltaker.');
        $room = $_GET['room'] ?? ''; $host = ($_GET['host'] ?? '') === '1';
        if (!is_string($room)) throw new DomainException('Ugyldig spill.');
        switch ($action) {
            case 'library': lq_response(['quizzes'=>lq_query($db, 'SELECT id, title, revision FROM lq_quizzes WHERE owner_id = ? ORDER BY updated_at DESC', [$uid])->fetchAll(), 'rooms'=>lq_query($db, 'SELECT id, pin, phase FROM lq_rooms WHERE owner_id = ? AND expires_at > ? ORDER BY expires_at DESC LIMIT 20', [$uid,time()])->fetchAll()]);
            case 'quiz': $q = lq_quiz($db, $uid, jp_text($_GET['id'] ?? '', 32)); lq_response(['id'=>$q['id'], 'revision'=>(int)$q['revision'], 'content'=>json_decode($q['content'], true, 32, JSON_THROW_ON_ERROR)]);
            case 'save': lq_response(lq_save($db, $uid, $input));
            case 'create': lq_response(lq_create_room($db, $uid, jp_text($input['id'] ?? '', 32)));
            case 'join': lq_response(lq_join($db, jp_text($input['pin'] ?? '', 6), jp_text($input['name'] ?? '', 80), $token));
            case 'control': lq_response(lq_control($db, $uid, $input));
            case 'answer': lq_response(lq_answer($db, $input, $token));
            case 'state': lq_response(lq_state($db, $room, $uid, $token, $host));
            case 'upload': lq_response(['image'=>jp_upload($db, $uid, $_FILES['image'] ?? [])]);
            case 'media':
                $image = lq_id($_GET['image'] ?? null);
                if ($room !== '') $m = lq_room_media($db, $room, $uid, $token, $host, $image);
                elseif ($uid) $m = jp_media($db, $image, $uid);
                else throw new DomainException('Ingen tilgang.');
                header('Content-Type: '.$m['mime']); header('Content-Length: '.strlen($m['bytes'])); echo $m['bytes']; exit;
            default: lq_response(['error'=>'Ukjent handling.'], 404);
        }
    } catch (DomainException|JsonException $e) { lq_response(['error'=>$e instanceof JsonException ? 'Ugyldig JSON.' : $e->getMessage()], 422); }
    catch (Throwable $e) { error_log('Livequiz: '.get_class($e).' '.$e->getCode()); lq_response(['error'=>'Tjenesten er utilgjengelig. Ingen lagring er bekreftet. Prøv igjen.'], 503); }
}
session_write_close();
?>
<!doctype html>
<html lang="nb"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Livequiz · Munchboka</title>
<link rel="stylesheet" href="../vendor/katex/katex.min.css"><link rel="stylesheet" href="app.css">
<script defer src="../vendor/katex/katex.min.js"></script><script defer src="../math.js"></script><script defer src="vendor/qrcode.js"></script><script defer src="app.js"></script></head>
<body><header><a class="brand" href="./">Munchboka <strong>Livequiz</strong></a><span class="badge">Utprøving</span><nav><a href="?teacher=1">Lag en quiz</a><a href="/" target="_blank" rel="noopener">Jeopardy / Logg inn</a></nav></header>
<main><div id="notice" role="alert" hidden></div><div id="app"><p>Laster …</p></div></main><footer>Spørsmål, samtale og læring · En klasse om gangen</footer></body></html>
